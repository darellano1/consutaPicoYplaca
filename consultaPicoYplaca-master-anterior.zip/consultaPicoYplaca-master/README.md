# consultaPicoYplaca
Proyecto que permite verificar si un automovil puede circular en el pico y placa ingresando la placa, la hora y la fecha
