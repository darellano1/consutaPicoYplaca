package com.picoYplacaPredictor.puebas;

import javax.swing.JOptionPane;

import com.picoYplacaPredictor.dtos.AutomovilDto;
import com.picoYplacaPredictor.dtos.excepciones.AutomovilDtoValidacionException;
import com.picoYplacaPredictor.servicios.ConsultarHabilitacionVehicular;

public class Pruebas {

	public static void main(String[] args) {
//		Utilidades utilidades = new Utilidades();
		ConsultarHabilitacionVehicular habilitacionVehicular = new ConsultarHabilitacionVehicular();
	
		String fechaEntrada = JOptionPane.showInputDialog("Ingrese la fecha (dd/MM/aaaa)");
		String placa = JOptionPane.showInputDialog("Ingrese la placa (ABC1234)");
		String hora = JOptionPane.showInputDialog("Ingrese la hora (hh:mm)");
		
		AutomovilDto automovil = new AutomovilDto();
		automovil.setAutId(1);
		automovil.setAutPlaca(placa);
		automovil.setAutPuedeConducir(1);// no puede conducir
			
		try {
			automovil = habilitacionVehicular.vehiculoHabilitado(automovil, fechaEntrada, hora);
		} catch (AutomovilDtoValidacionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(automovil.getAutPuedeConducir() == 0){
			JOptionPane.showConfirmDialog(null, "Puede circular el automovil", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE);
		}else{
			if(automovil.getAutPuedeConducir() == 1){
				JOptionPane.showConfirmDialog(null, "No puede circular el automovil", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE);
			}
		}

	}

}
