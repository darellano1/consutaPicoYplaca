package com.picoYplacaPredictor.puebas;

import javax.swing.JOptionPane;

import com.picoYplacaPredictor.utilidades.Utilidades;

public class test {
	public static void main(String[] args) {
		String placaEntrada = JOptionPane.showInputDialog("Ingresa la hora");
//		String[] parts = fechaEntrada.split("");
//		String uno = parts[0];
//		String dos = parts[1];
//		String tres = parts[2];
//		String cuatro = parts[3];
//		String cinco = parts[4];
//		String seis = parts[5];
//		String siete = parts[6];
//		System.out.println(uno +" "+ dos +" "+tres +" "+cuatro +" "+cinco +" "+seis +" "+siete);
//		System.out.println("length "+ parts.length);
		
		Utilidades ut = new Utilidades();
		Boolean placaOk = ut.verificarHoraRegex(placaEntrada);
		if(placaOk){
			JOptionPane.showConfirmDialog(null, "hora correcta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE);
		}else{
			JOptionPane.showConfirmDialog(null, "hora incorrecta ", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE);
		}
		
	}

}
