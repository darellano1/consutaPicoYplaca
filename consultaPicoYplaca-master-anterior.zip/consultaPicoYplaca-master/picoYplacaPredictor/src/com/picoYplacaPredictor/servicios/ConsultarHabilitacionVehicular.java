package com.picoYplacaPredictor.servicios;

import javax.swing.JOptionPane;

import com.picoYplacaPredictor.dtos.AutomovilDto;
import com.picoYplacaPredictor.dtos.excepciones.AutomovilDtoValidacionException;
import com.picoYplacaPredictor.utilidades.Utilidades;

/**
 * Clase ConsultarHabilitacionVehicular.
 * Clase que permite hacer las consultas para el pico y placa.
 * @author darellano
 * @version 1.0
 */
public class ConsultarHabilitacionVehicular {

	/**
	 * Método que verifica si el vehiculo está habilitado para circular
	 * @param automovil - objeto automovil que se requiere consular la habilitación vehicular
	 * @param fecha - fecha que se desea consultar la habilitacion vehicular
	 * @param hora - hora que se desea consultar la habilitacion vehicular
	 * @return - objeto automovil con los datos consultados
	 */
	public AutomovilDto vehiculoHabilitado (AutomovilDto automovil, String fecha, String hora ) throws AutomovilDtoValidacionException {
		AutomovilDto retorno = automovil;
		Utilidades utilidades = new Utilidades();
		String diaDeLaSemana = new String();
		
		Boolean fechaOk = utilidades.verificarFechaRegex(fecha);
		Boolean horaOk = utilidades.verificarHoraRegex(hora);
		Boolean placaOk = utilidades.verificarPlacaRegex(automovil.getAutPlaca());
		
		if(fechaOk && horaOk && placaOk){
			diaDeLaSemana = utilidades.obtenerDiaDeLaSemanaString(fecha);
			Integer ultimoDigitoPlaca = Character.getNumericValue(automovil.getAutPlaca().charAt(automovil.getAutPlaca().length()-1));
			
			Boolean picoYplaca = utilidades.tienePicoYplaca(diaDeLaSemana, ultimoDigitoPlaca);
			Integer[] horaArray = utilidades.transformarHoraAarray(hora);
			
			if(picoYplaca == true){ // tiene pico y placa ?
				if(horaArray[0] >= 7 && horaArray[0] <= 9){
					retorno.setAutPuedeConducir(1); // no puede circular
					if(horaArray[0] == 9 && horaArray[1] >= 30 ){
						retorno.setAutPuedeConducir(0); // puede circular
					}
				}else{
					if(horaArray[0] >= 16 && horaArray[0] <= 19){
						retorno.setAutPuedeConducir(1); // no puede circular
						if(horaArray[0] == 19 && horaArray[1] >= 30 ){
							retorno.setAutPuedeConducir(0); // puede circular
						}
					}else{
						retorno.setAutPuedeConducir(0); // puede circular
					}
				}
			}else{
				retorno.setAutPuedeConducir(0); // puede circular
			}
		}else{
			if(!fechaOk && !horaOk && !placaOk){
				JOptionPane.showConfirmDialog(null, "La fecha, la hora y la placa ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
				throw new AutomovilDtoValidacionException(); 
			}else{
				if(!fechaOk && !horaOk ){
					JOptionPane.showConfirmDialog(null, "La fecha y la hora ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
					throw new AutomovilDtoValidacionException(); 
				}else{
					if(!fechaOk && !placaOk){
						JOptionPane.showConfirmDialog(null, "La fecha y la placa ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
						throw new AutomovilDtoValidacionException(); 
					}else{
						if(!horaOk && !placaOk){
							JOptionPane.showConfirmDialog(null, "La hora y la placa ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
							throw new AutomovilDtoValidacionException(); 
						}else{
							if(!fechaOk){
								JOptionPane.showConfirmDialog(null, "La fecha ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
								throw new AutomovilDtoValidacionException(); 
							}else{
								if(!horaOk){
									JOptionPane.showConfirmDialog(null, "La hora ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
									throw new AutomovilDtoValidacionException(); 
								}else{
									if(!placaOk){
										JOptionPane.showConfirmDialog(null, "La placa ingesada es incorrecta", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
										throw new AutomovilDtoValidacionException(); 
									}
								}
							}
						}
					}
				}
			}

		}
		return retorno;
	}
	
}
