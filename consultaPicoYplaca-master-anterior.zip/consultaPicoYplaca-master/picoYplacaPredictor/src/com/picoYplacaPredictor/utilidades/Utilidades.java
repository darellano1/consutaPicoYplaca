package com.picoYplacaPredictor.utilidades;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

/**
 * Clase Utilidades.
 * Clase que permite hacer uso de utilidades para la consulta del pico y placa.
 * @author darellano
 * @version 1.0
 */
public class Utilidades {
	
	/**
	 * Método que permite transformar un string a Calendar
	 * @param fechaEnString - cadena de la fecha que se desea trasnformar
	 * @return - Objeto Calendar transformado
	 */
	private Calendar stringToCalendar(String fechaEnString) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar retorno = null;
	    try {
	    	Date date = sdf.parse(fechaEnString);
	    	Calendar calendar = Calendar.getInstance();
	    	calendar.setTime(date);
	    	retorno = calendar;
	    } catch (ParseException e) {
	    	JOptionPane.showConfirmDialog(null, "Error al transformar la fecha", "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE);
	    } 
	    return retorno;
	}
	
	/**
	 * Método para obtener el dia de la semana a partir de una fecha
	 * @param fechaEnString - fecha en String que se desea buscar el día de la semana que es
	 * @return Objeto String del día de la semana que le corresponde a una fecha
	 */
	public String obtenerDiaDeLaSemanaString(String fechaEnString){
		Calendar fecha = stringToCalendar(fechaEnString);
		String [] diasDeLaSemana = new String []{"Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"};
		int diaInt = fecha.get(Calendar.DAY_OF_WEEK );
		return diasDeLaSemana[diaInt -1];
	}
	
	/**
	 * Método para transformar la hora en String a un arreglo
	 * @param horaString - hora en string que se quiere transformar en un arreglo
	 * @return - Objeto Array de integer de la hora 
	 */
	public Integer[] transformarHoraAarray(String horaString){
		String[] partes = horaString.split(":");
		Integer[] retorno = new Integer[2];
		retorno[0]= Integer.parseInt(partes[0]); //horas
		retorno[1]= Integer.parseInt(partes[1]); //minutos
		return retorno;
	}
	
	/**
	 * Método para verificar si un auto tiene o no pico y placa
	 * @param diaDeLaSemana - dia de la semana que se requeire consultar
	 * @param ultimoDigitoPlaca - utimo dígito de la placa del automovil que se requiere consultar
	 * @return - Objeto Boolean que indica true si tiene pico y placa, false caso contrario
	 */
	public Boolean tienePicoYplaca(String diaDeLaSemana, Integer ultimoDigitoPlaca ){
		Boolean tienePicoYplaca = false;
		switch (diaDeLaSemana) {
		case "Lunes":
			if(ultimoDigitoPlaca == 1){
				tienePicoYplaca = true;
			}else{
				if(ultimoDigitoPlaca == 2){
					tienePicoYplaca = true;
				}
			}
			break;
		case "Martes":
			if(ultimoDigitoPlaca == 3){
				tienePicoYplaca = true;
			}else{
				if(ultimoDigitoPlaca == 4){
					tienePicoYplaca = true;
				}
			}
			break;
		case "Miercoles":
			if(ultimoDigitoPlaca == 5){
				tienePicoYplaca = true;
			}else{
				if(ultimoDigitoPlaca == 6){
					tienePicoYplaca = true;
				}
			}
			break;
		case "Jueves":
			if(ultimoDigitoPlaca == 7){
				tienePicoYplaca = true;
			}else{
				if(ultimoDigitoPlaca == 8){
					tienePicoYplaca = true;
				}
			}
			break;
		case "Viernes":
			if(ultimoDigitoPlaca == 9){
				tienePicoYplaca = true;
			}else{
				if(ultimoDigitoPlaca == 0){
					tienePicoYplaca = true;
				}
			}
			break;
		case "Sabado":
			tienePicoYplaca = false;
			break;
		case "Domingo":
			tienePicoYplaca = false;
			break;
		default:
			break;
		}
		
		return tienePicoYplaca;
	}
	
	/**
	 * Método que permite verificar que la fecha esté escrito en el formato solicitado
	 * @param fecha - string de la fecha que se desea validar
	 * @return - Objeto Boolean que indica true si la fecha está correcta, false caso contrario
	 */
	public Boolean verificarFecha(String fecha){
		
		String[] partes = fecha.split("/");
		Boolean retorno = false;
		Integer dia = Integer.parseInt(partes[0]); // dia
		Integer mes = Integer.parseInt(partes[1]); // mes
		Integer anio = Integer.parseInt(partes[2]); // año
		if(dia <= 31 && dia > 0){
			if(mes <= 12 && mes > 0){
				if(anio <= 9999 && anio > 0){
					retorno = true;
				}else{
					retorno = false;
				}
			}else{
				retorno = false;
			}
		}else{
			retorno = false;
		}
		
		return retorno;
	}
	
	/**
	 * Método que permite verificar que la fecha esté escrito en el formato solicitado mediante un regex
	 * @param fecha - string de la fecha que se desea validar
	 * @return - Objeto Boolean que indica true si la fecha está correcta, false caso contrario
	 */
	public Boolean verificarFechaRegex(String fecha){
		
		Boolean retorno = false;
		String PATRON_FECHA = "[0-9]{1,2}/[0-9]{2}/[0-9]{4}";
		Pattern pattern = Pattern.compile(PATRON_FECHA);
		Matcher matcher = pattern.matcher(fecha);
		
		if(!matcher.matches()){
			retorno = false; 
		}else{
			String[] partes = fecha.split("/");
			Integer dia = Integer.parseInt(partes[0]); // dia
			Integer mes = Integer.parseInt(partes[1]); // mes
			Integer anio = Integer.parseInt(partes[2]); // año
			Boolean anioBisiesto = false;
			
			if(anio%4 == 0){
				anioBisiesto = true;
			}else{
				anioBisiesto = false;
			}
			
			if(dia.intValue() <= 31 && dia.intValue() > 1){ // verifico que los dias solo puedan tener entre 1 y 31
				if(mes.intValue() <= 12 && mes.intValue() > 1){ // verifico que los meses esten entre 1 y 12 
					if(anio <= 9999 && anio > 1){ // verifico que el anio este entre 1 y 9999
						if((mes.intValue() == 4 ||mes.intValue() == 6 ||mes.intValue() == 9 ||mes.intValue() ==11) && dia<=30){// verifico que  en estos meses solo haya 30 días
							retorno = true;
						}else{
							if(mes.intValue() == 2){ // verifico que en febrero exista maximo 29 días
								if(anioBisiesto && dia <= 29){ // verifico si es anio biciesto tiene que tener 29 dias maximo febrero
									retorno = true;
								}else{
									if(!anioBisiesto && dia.intValue() <= 28){ // verifico si no es anio biciesto tiene que tener 28 dias máximo febrero
										retorno = true;
									}else{
										retorno = false;
									}
								}
							}else{
								if(dia <= 31){
									retorno = true;
								}else{
									retorno = false;
								}
							}
						}
					}else{
						retorno = false;
					}
				}else{
					retorno = false;
				}
			}else{
				retorno = false;
			}
		}
		return retorno;
	}
	
	/**
	 * Método que permite verificar que la hora esté escrito en el formato solicitado
	 * @param hora - string de la horaque se desea validar
	 * @return - Objeto Boolean que indica true si la hora está correcta, false caso contrario
	 */
	public Boolean verificarHora(String hora){
		String[] partes = hora.split(":");
		Boolean retorno = false;
		Integer horas = Integer.parseInt(partes[0]); // horas
		Integer minutos = Integer.parseInt(partes[1]); // minutos
		if(horas <= 24 && horas >= 0){
			if(minutos <= 60 && minutos >= 0){
				retorno = true;
			}
		}else{
			retorno = false;
		}
		return retorno;
	}
	
	/**
	 * Método que permite verificar que la hora esté escrito en el formato solicitado mediante un regex
	 * @param hora - string de la horaque se desea validar
	 * @return - Objeto Boolean que indica true si la hora está correcta, false caso contrario
	 */
	public Boolean verificarHoraRegex(String hora){
		
		Boolean retorno = false;
		String PATRON_HORA = "[0-9]{1,2}:[0-9]{2}";
		Pattern pattern = Pattern.compile(PATRON_HORA);
		Matcher matcher = pattern.matcher(hora);
		if(!matcher.matches()){
			retorno = false; 
		}else{
			String[] partes = hora.split(":");
			Integer horas = Integer.parseInt(partes[0]); // horas
			Integer minutos = Integer.parseInt(partes[1]); // minutos
			if(horas <= 24 && horas >= 0){
				if(minutos <= 60 && minutos >= 0){
					retorno = true;
				}
			}else{
				retorno = false;
			}
		}
		return retorno;
		
		

	}

	/**
	 * Método que permite verificar que la placa esté escrita en el formato correcto 
	 * @param placa - string de la placa que se desea validar
	 * @return - Objeto Boolean que indica true si la placa está correcta, false caso contrario
	 */
	public Boolean verificarPlaca(String placa){
		String[] partes = placa.split("");
		Boolean retorno = false;
		try {
			if(partes.length == 7){
				Integer.parseInt(partes[3]);
				Integer.parseInt(partes[4]);
				Integer.parseInt(partes[5]);
				Integer.parseInt(partes[6]);
				retorno = true;
			}else{
				if(partes.length == 6){
					Integer.parseInt(partes[3]);
					Integer.parseInt(partes[4]);
					Integer.parseInt(partes[5]);
					retorno = true;
					}else{
						retorno = false;
					}
				}
			
		} catch (NumberFormatException e) {
			return false;
		}
		return retorno;
	}
	
	/**
	 * Método que permite verificar que la placa esté escrita en el formato correcto mediante un regex
	 * @param placa - string de la placa que se desea validar
	 * @return - Objeto Boolean que indica true si la placa está correcta, false caso contrario
	 */
	public Boolean verificarPlacaRegex(String placa){
		Boolean retorno = false;
		String PATRON_PLACA = "[A-Za-z]{3}+[0-9]{3,4}";
		Pattern pattern = Pattern.compile(PATRON_PLACA);
		Matcher matcher = pattern.matcher(placa);
		if(!matcher.matches()){
			retorno = false; 
		}else{
			retorno = true;
		}
		return retorno;
	}
}
